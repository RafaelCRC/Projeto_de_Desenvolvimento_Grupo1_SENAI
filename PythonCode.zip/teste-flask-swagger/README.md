# flask-experiments
Experimentos com flask


todo: alterar versão Werkzeug==0.16.1
